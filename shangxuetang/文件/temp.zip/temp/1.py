# _*_ coding:utf-8 _*_
# @time  : 2021/1/23 22:47
# @Author: quanwen
# @File  :

print('1111111')